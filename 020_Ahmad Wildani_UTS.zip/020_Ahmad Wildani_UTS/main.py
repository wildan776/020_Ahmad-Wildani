# data arus listrik
data_inti = (1.6, 2.2, 3.5, 4.1, 5.4, 2.8, 6.0, 3.9, 1.9, 4.8, 5.1, 2.6, 3.2, 4.4, 5.8)
data_tambahan = (1.0, 3.1, 3.2, 4.5, 5.5)


tegangan = 220
# menggabungkan data inti dan data tambahan
data_arus = data_inti + data_tambahan
# fungsi menghitung daya listrik
def hitung_daya(V, I):
    p = V * I
    return p

# fungsi menentukan status beban
def status_beban(P):
    if P <= 700 :
        return "NORMAL"
    elif P <= 1000 :
        return "WARNING"
    else :
        return "BEBAN TINGGI"

# menghitug rata-rata
def rata_rata(data):
    total = sum(data)
    return total / len(data)

# PROGRAM UTAMA
jumlah_normal = 0
jumlah_warning = 0
jumlah_beban_tinggi = 0
data_daya = []

print("=" * 65)
print("PROGRAM MONITORING BEBAN / DAYA LISTRIK")
print("=" * 65)
print(f"{'No':<5}{'Arus (A)':<15}{'Daya (W)':<15}{'status beban'}")
print("=" * 65)

# memproses seluruh 20 data 
for i, arus in enumerate(data_arus, start=1):
    daya = hitung_daya(tegangan, arus)
    status = status_beban(daya)
    data_daya.append(daya)

    if status == "NORMAL":
        jumlah_normal += 1  
    elif status == "WARNING":
        jumlah_warning += 1
    else:
        jumlah_beban_tinggi += 1

# menampilkan hasil setiap data
    print(f"{i:<5}{arus:<15.2f}{daya:<15.2f}{status}")
# menghitung ringkasan
rata_arus = rata_rata(data_arus)
rata_daya = rata_rata(data_daya)
daya_maksimum = max(data_daya)
daya_minimum = min(data_daya)
print("=" * 65)
print("RINGKASAN HASIL MONITORING")
print("=" * 65)
print(f"Rata-rata Arus: {rata_arus:.2f} A")
print(f"Rata-rata Daya: {rata_daya:.2f} W")
print(f"Daya Maksimum: {daya_maksimum} W")
print(f"Daya Minimum: {daya_minimum} W")
print(f"Jumlah Normal: {jumlah_normal}")
print(f"Jumlah Warning: {jumlah_warning}")
print(f"Jumlah Beban Tinggi: {jumlah_beban_tinggi}")

# ==========================================
# TESTING PROGRAM MONITORING DAYA LISTRIK
# ==========================================

print("\n")
print("=" * 65)
print("TESTING PROGRAM")
print("=" * 65)

# 8 test case
test_cases = [
    (699.9, "NORMAL"),
    (700, "NORMAL"),
    (700.1, "WARNING"),
    (999.9, "WARNING"),
    (1000, "WARNING"),
    (1000.1, "BEBAN TINGGI"),
    (220, "NORMAL"),
    (1320, "BEBAN TINGGI")
]

# Menjalankan seluruh test case
for nomor, (daya, expected) in enumerate(test_cases, start=1):

    actual = status_beban(daya)

    if actual == expected:
        hasil = "PASS"
    else:
        hasil = "FAIL"

    print(f"Test {nomor}")
    print(f"Input           : {daya} W")
    print(f"Expected Output : {expected}")
    print(f"Actual Output   : {actual}")
    print(f"Hasil           : {hasil}")
    print("-" * 65)
